import setuptools

setuptools.setup(
    name='img_scrapper+mail',
    version='0.1',
    author='Milosz Hoc',
    author_email='miloszhoc@gmail.com',
    packages=setuptools.find_packages()

)
