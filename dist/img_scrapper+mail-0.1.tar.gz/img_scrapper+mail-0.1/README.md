Script is able to download any number of photos from any flickr group
and send everyday different photo to each person from mailing list.

used modules:
-smtplib
-ssl
-time
-traceback
-email.mime.image
-email.mime.multipart
-requests
-flickrapi
-json
-subprocess